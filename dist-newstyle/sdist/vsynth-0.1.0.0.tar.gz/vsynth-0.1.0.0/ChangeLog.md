# Changelog for vsynth

## Unreleased changes
